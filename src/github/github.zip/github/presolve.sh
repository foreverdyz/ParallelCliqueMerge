#!/bin/bash

julia --threads 64 presolve.jl