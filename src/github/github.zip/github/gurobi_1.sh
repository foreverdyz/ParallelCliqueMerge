#!/bin/bash

julia --threads 64 test_runtime.jl